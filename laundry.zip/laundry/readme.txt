Halaman Admin
>>>>>>>>>>>>>
username = admin
password = admin

Halaman Kasir
>>>>>>>>>>>>>
username = kasirmerah
password = kasirmerah

username = kasirputih
password = kasirputih

Halaman Owner
>>>>>>>>>>>>>
username = owner
password = owner

#gimme more stars :)


